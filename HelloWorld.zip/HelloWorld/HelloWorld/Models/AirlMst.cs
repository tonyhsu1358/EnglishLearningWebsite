﻿using System;
using System.Collections.Generic;

namespace HelloWorld.Models;

public partial class AirlMst
{
    public int AirlId { get; set; }

    public string AirlCode { get; set; }

    public string AirlName { get; set; }

    public virtual ICollection<FligMst> FligMsts { get; set; } = new List<FligMst>();
}
