﻿using System;
using System.Collections.Generic;

namespace HelloWorld.Models;

public partial class FligDtl
{
    public int DtlId { get; set; }

    public int FligId { get; set; }

    public string CargoNo { get; set; }

    public string CargoType { get; set; }

    public decimal CargoWeight { get; set; }

    public string CargoDesc { get; set; }

    public virtual FligMst Flig { get; set; }
}
