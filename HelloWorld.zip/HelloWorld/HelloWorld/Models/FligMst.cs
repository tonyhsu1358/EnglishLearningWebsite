﻿using System;
using System.Collections.Generic;

namespace HelloWorld.Models;

public partial class FligMst
{
    public int FligId { get; set; }

    public string FligNo { get; set; }

    public int AirlId { get; set; }

    public int DeptAirpId { get; set; }

    public int ArvlAirpId { get; set; }

    public DateTime DeptTime { get; set; }

    public DateTime ArvlTime { get; set; }

    public virtual AirlMst Airl { get; set; }

    public virtual AirpMst ArvlAirp { get; set; }

    public virtual AirpMst DeptAirp { get; set; }

    public virtual ICollection<FligDtl> FligDtls { get; set; } = new List<FligDtl>();
}
