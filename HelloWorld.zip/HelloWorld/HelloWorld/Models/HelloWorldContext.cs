﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace HelloWorld.Models;

public partial class HelloWorldContext : DbContext
{
    public HelloWorldContext()
    {
    }

    public HelloWorldContext(DbContextOptions<HelloWorldContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AirlMst> AirlMsts { get; set; }

    public virtual DbSet<AirpMst> AirpMsts { get; set; }

    public virtual DbSet<FligDtl> FligDtls { get; set; }

    public virtual DbSet<FligMst> FligMsts { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=localhost\\SQLEXPRESS;Database=TEST1;Trusted_Connection=True;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AirlMst>(entity =>
        {
            entity.HasKey(e => e.AirlId);

            entity.ToTable("AIRL_MST");

            entity.Property(e => e.AirlId).HasColumnName("AIRL_ID");
            entity.Property(e => e.AirlCode)
                .IsRequired()
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("AIRL_CODE");
            entity.Property(e => e.AirlName)
                .IsRequired()
                .HasMaxLength(50)
                .HasColumnName("AIRL_NAME");
        });

        modelBuilder.Entity<AirpMst>(entity =>
        {
            entity.HasKey(e => e.AirpId);

            entity.ToTable("AIRP_MST");

            entity.Property(e => e.AirpId).HasColumnName("AIRP_ID");
            entity.Property(e => e.AirpCode)
                .IsRequired()
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("AIRP_CODE");
            entity.Property(e => e.AirpName)
                .IsRequired()
                .HasMaxLength(100)
                .HasColumnName("AIRP_NAME");
        });

        modelBuilder.Entity<FligDtl>(entity =>
        {
            entity.HasKey(e => e.DtlId);

            entity.ToTable("FLIG_DTL");

            entity.Property(e => e.DtlId).HasColumnName("DTL_ID");
            entity.Property(e => e.CargoDesc)
                .HasMaxLength(100)
                .HasColumnName("CARGO_DESC");
            entity.Property(e => e.CargoNo)
                .IsRequired()
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("CARGO_NO");
            entity.Property(e => e.CargoType)
                .IsRequired()
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("CARGO_TYPE");
            entity.Property(e => e.CargoWeight)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("CARGO_WEIGHT");
            entity.Property(e => e.FligId).HasColumnName("FLIG_ID");

            entity.HasOne(d => d.Flig).WithMany(p => p.FligDtls)
                .HasForeignKey(d => d.FligId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DTL_FLIG");
        });

        modelBuilder.Entity<FligMst>(entity =>
        {
            entity.HasKey(e => e.FligId);

            entity.ToTable("FLIG_MST");

            entity.Property(e => e.FligId).HasColumnName("FLIG_ID");
            entity.Property(e => e.AirlId).HasColumnName("AIRL_ID");
            entity.Property(e => e.ArvlAirpId).HasColumnName("ARVL_AIRP_ID");
            entity.Property(e => e.ArvlTime)
                .HasColumnType("datetime")
                .HasColumnName("ARVL_TIME");
            entity.Property(e => e.DeptAirpId).HasColumnName("DEPT_AIRP_ID");
            entity.Property(e => e.DeptTime)
                .HasColumnType("datetime")
                .HasColumnName("DEPT_TIME");
            entity.Property(e => e.FligNo)
                .IsRequired()
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("FLIG_NO");

            entity.HasOne(d => d.Airl).WithMany(p => p.FligMsts)
                .HasForeignKey(d => d.AirlId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FLIG_AIRL");

            entity.HasOne(d => d.ArvlAirp).WithMany(p => p.FligMstArvlAirps)
                .HasForeignKey(d => d.ArvlAirpId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FLIG_ARVL");

            entity.HasOne(d => d.DeptAirp).WithMany(p => p.FligMstDeptAirps)
                .HasForeignKey(d => d.DeptAirpId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FLIG_DEPT");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
