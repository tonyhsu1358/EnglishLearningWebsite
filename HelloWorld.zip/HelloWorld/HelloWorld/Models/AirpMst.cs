﻿using System;
using System.Collections.Generic;

namespace HelloWorld.Models;

public partial class AirpMst
{
    public int AirpId { get; set; }

    public string AirpCode { get; set; }

    public string AirpName { get; set; }

    public virtual ICollection<FligMst> FligMstArvlAirps { get; set; } = new List<FligMst>();

    public virtual ICollection<FligMst> FligMstDeptAirps { get; set; } = new List<FligMst>();
}
