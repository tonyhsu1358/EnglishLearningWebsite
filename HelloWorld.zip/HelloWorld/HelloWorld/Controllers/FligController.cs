﻿using HelloWorld.Dtos; // 引用 DTO
using HelloWorld.ViewModels;
using HelloWorld.Models;
using Microsoft.AspNetCore.Mvc;

namespace HelloWorld.Controllers
{
    public class FligController : Controller
    {
        private readonly HelloWorldContext _context;

        public FligController(HelloWorldContext context)
        {
            _context = context;
        }

        // ===========================
        // 航班列表頁（之後你可以自己做）
        // ===========================
        public IActionResult Index()
        {
            return View();
        }

        // ===========================
        // 航班貨運明細綜合查詢 (固定查詢)
        // ===========================
        public IActionResult CargoReport()
        {
            // 1. 固定查詢：只取重量 >= 100 的貨物
            var result =
                from m in _context.FligMsts              // 從航班主檔 (FLIG_MST) 取出資料，命名為 m
                join d in _context.FligDtls              // 與航班貨運明細檔 (FLIG_DTL) 做 INNER JOIN
                    on m.FligId equals d.FligId          // 條件：航班 ID 相同
                join al in _context.AirlMsts             // 與航空公司主檔 (AIRL_MST) 做 INNER JOIN
                    on m.AirlId equals al.AirlId         // 條件：航空公司 ID 相同
                join ap1 in _context.AirpMsts            // 與機場主檔 (AIRP_MST) 做 INNER JOIN（起飛機場）
                    on m.DeptAirpId equals ap1.AirpId    // 條件：起飛機場 ID 相同
                join ap2 in _context.AirpMsts            // 與機場主檔 (AIRP_MST) 做 INNER JOIN（抵達機場）
                    on m.ArvlAirpId equals ap2.AirpId    // 條件：抵達機場 ID 相同
                where d.CargoWeight >= 100               // 篩選條件：只取貨物重量 >= 100 KG 的資料
                orderby m.FligNo, d.CargoNo              // 排序：先依航班編號，再依貨物編號（預設升冪）
                select new FligCargoDto                  // 查詢結果投影成 DTO（自訂的資料容器）
                {
                    FligNo = m.FligNo,                   // 左邊是 DTO 欄位，右邊是 Model (資料表) 欄位
                    AirlName = al.AirlName,
                    DeptAirpName = ap1.AirpName,
                    ArvlAirpName = ap2.AirpName,
                    CargoNo = d.CargoNo,
                    CargoType = d.CargoType,
                    CargoWeight = d.CargoWeight,
                    CargoDesc = d.CargoDesc
                };

            // 2. 建立 ViewModel，包含固定查詢結果 + 下拉選單
            var vm = new CargoReportViewModel
            {
                Airlines = _context.AirlMsts.ToList(),
                FixedResults = result.ToList()
            };

            return View(vm);
        }

        // ===========================
        // 航班貨運明細綜合動態查詢 (依使用者輸入)
        // ===========================
        [HttpGet]
        public IActionResult CargoReportQuery(int? airlId, int? minWeight)
        {
            var vm = new CargoReportViewModel();
            vm.Airlines = _context.AirlMsts.ToList();

            // 固定查詢 (重量 >= 100) → 每次都要塞回去
            vm.FixedResults =
                (from m in _context.FligMsts
                 join d in _context.FligDtls on m.FligId equals d.FligId
                 join al in _context.AirlMsts on m.AirlId equals al.AirlId
                 join ap1 in _context.AirpMsts on m.DeptAirpId equals ap1.AirpId
                 join ap2 in _context.AirpMsts on m.ArvlAirpId equals ap2.AirpId
                 where d.CargoWeight >= 100
                 orderby m.FligNo, d.CargoNo
                 select new FligCargoDto
                 {
                     FligNo = m.FligNo,
                     AirlName = al.AirlName,
                     DeptAirpName = ap1.AirpName,
                     ArvlAirpName = ap2.AirpName,
                     CargoNo = d.CargoNo,
                     CargoType = d.CargoType,
                     CargoWeight = d.CargoWeight,
                     CargoDesc = d.CargoDesc
                 }).ToList();

            // 動態查詢 (依使用者輸入)
            if (airlId.HasValue && minWeight.HasValue)
            {
                vm.DynamicResults =
                    (from m in _context.FligMsts
                     join d in _context.FligDtls on m.FligId equals d.FligId
                     join al in _context.AirlMsts on m.AirlId equals al.AirlId
                     join ap1 in _context.AirpMsts on m.DeptAirpId equals ap1.AirpId
                     join ap2 in _context.AirpMsts on m.ArvlAirpId equals ap2.AirpId
                     where d.CargoWeight >= minWeight.Value
                           && (airlId.Value == 0 || m.AirlId == airlId.Value)
                     orderby m.FligNo, d.CargoNo
                     select new FligCargoDto
                     {
                         FligNo = m.FligNo,
                         AirlName = al.AirlName,
                         DeptAirpName = ap1.AirpName,
                         ArvlAirpName = ap2.AirpName,
                         CargoNo = d.CargoNo,
                         CargoType = d.CargoType,
                         CargoWeight = d.CargoWeight,
                         CargoDesc = d.CargoDesc
                     }).ToList();
            }

            return View("CargoReport", vm);
        }


    }
}
