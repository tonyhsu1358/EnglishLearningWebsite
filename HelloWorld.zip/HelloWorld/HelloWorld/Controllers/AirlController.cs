﻿using Microsoft.AspNetCore.Mvc;
using HelloWorld.Models;
using HelloWorld.Dtos; 

namespace HelloWorld.Controllers
{
    public class AirlController : Controller
    {
        private readonly HelloWorldContext _context;
        // _context：資料庫 DbContext，用來查詢 / 新增 / 修改 / 刪除資料
        //這是 依賴注入 (Dependency Injection, DI) 的典型寫法，用來在類別裡取得資料庫物件

        public AirlController(HelloWorldContext context)
        {
            // 建構子：把 DI 傳進來的資料庫物件存起來，整個 Controller 都能用
            _context = context;
        }

        // ===========================
        // 列表頁（Index）
        // ===========================
        public IActionResult Index()
        {
            // 撈出 AIRL_MST 全部資料，準備給列表頁顯示
            var airlList = _context.AirlMsts.ToList();

            // 額外撈出「中華航空」那一筆資料
            var chinaAir = _context.AirlMsts
                                   .FirstOrDefault(x => x.AirlName == "中華航空");

            // 用 ViewBag 傳給 View（額外資料）
            ViewBag.ChinaAir = chinaAir;

            // 把列表資料 airlList 傳給 Index.cshtml
            return View(airlList);
        }

        // ===========================
        // 新增頁面（GET）
        // ===========================
        public IActionResult Create()
        {
            // 顯示空白表單（Create.cshtml）
            return View();
        }

        // ===========================
        // 接收表單送出的資料（POST）
        // ===========================
        [HttpPost]
        public IActionResult Create(AirlCreateDto dto)
        {
            // model：接住表單送來的資料（AirlCode、AirlName）

            // 檢查資料是否符合 Model 規則（例如必填）
            if (ModelState.IsValid)
            {
                //把 Dto 轉換為Model 
                var model = new AirlMst {
                    AirlCode = dto.AirlCode, // 左邊是 Model (資料表) 欄位，右邊是 DTO 欄位
                    AirlName  = dto.AirlName
                };
                
                // 把新資料加入資料庫追蹤
                _context.AirlMsts.Add(model);
                // 寫入資料庫
                _context.SaveChanges();

                // 新增成功 → 回到列表頁
                return RedirectToAction("Index");
            }

            // 若驗證失敗 → 回到表單並顯示原本輸入的資料
            return View(dto);
        }
    }
}
