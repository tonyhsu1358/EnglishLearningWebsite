﻿using Microsoft.AspNetCore.Mvc;

namespace HelloWorld.Controllers;
public class HomeController : Controller
{
    // 這是首頁的 Action
    // 當使用者進入/Home/Index或網站根目錄時，就會執行這裡
    public IActionResult Index()
    {
        // 回傳 Views/Home/Index.cshtml
        return View();
    }
}
