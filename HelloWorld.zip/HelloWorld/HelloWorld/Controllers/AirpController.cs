﻿using HelloWorld.Services;
using Microsoft.AspNetCore.Mvc;

namespace HelloWorld.Controllers
{
    // Controller 類別：負責「流程控制」
    // 當使用者瀏覽 /Airp/Index 時，會進到這裡
    public class AirpController : Controller
    {
        // 宣告一個唯讀欄位 _airpService
        // 型別：AirpService
        // 用途：呼叫 Service 取得機場資料
        private readonly AirpService _airpService;

        // 建構子注入：系統會自動把 AirpService 傳進來
        public AirpController(AirpService airpService)
        {
            _airpService = airpService;
        }

        // Action 方法：Index
        // 當使用者進到 /Airp/Index，就會執行這個方法
        public IActionResult Index()
        {
            // 呼叫 Service 的 GetAirports() 方法，取得機場清單
            var airports = _airpService.GetAirports();

            // 把機場清單丟給 View (Index.cshtml)，讓前端顯示
            return View(airports);
        }
    }
}
