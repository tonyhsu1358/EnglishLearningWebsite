﻿// 引入驗證相關的命名空間 (library)，裡面有 ValidationAttribute、Required 等常用驗證標籤
// 型別：命名空間 (System.ComponentModel.DataAnnotations)
// 用途：讓你能使用系統提供的驗證功能
using System.ComponentModel.DataAnnotations;

// 引入 Models 命名空間，因為要用到 HelloWorldContext (DbContext) 和 AirlMst (資料表 Model)
// 型別：命名空間 (HelloWorld.Models)
// 用途：讓程式能找到 DbContext 和資料表類別
using HelloWorld.Models;

// 宣告命名空間，把這個類別歸類到 HelloWorld.ValidationAttributes 底下
// 型別：命名空間 (HelloWorld.ValidationAttributes)
// 用途：分類程式碼，避免不同檔案的類別名稱衝突
namespace HelloWorld.ValidationAttributes
{
    // 宣告一個公開的類別 AirlUniqueAttribute
    // 型別：類別 (class AirlUniqueAttribute)
    // 繼承：ValidationAttribute (父類別，系統提供的驗證基底類別)
    // 用途：建立一個自訂驗證標籤
    public class AirlUniqueAttribute : ValidationAttribute
    {
        // 宣告一個方法 IsValid
        // protected → 存取修飾詞 (只能在自己或子類別裡用)
        // override → 覆寫父類別的方法
        // ValidationResult → 回傳型別 (系統提供的類別，用來表示驗證結果)
        // IsValid → 方法名稱
        // (object value, ValidationContext validationContext) → 方法參數列表
        //   object → 型別 (C# 所有型別的基底類別)
        //   value → 變數名稱，代表套用驗證標籤的欄位值 (例如 AirlCode)
        //   ValidationContext → 型別 (系統提供的驗證上下文物件)
        //   validationContext → 變數名稱，代表驗證時的上下文 (能拿到整個 DTO 和 DbContext)
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            // 宣告變數 _context
            // 型別：HelloWorldContext (你專案裡的 DbContext 類別)
            // 用途：連線到資料庫，查詢資料表
            // 右邊：validationContext.GetService(...) → 從 DI 容器拿出 DbContext
            // (HelloWorldContext) → 強制轉型成 HelloWorldContext 型別
            var _context = (HelloWorldContext)validationContext.GetService(typeof(HelloWorldContext));

            // 宣告變數 dto
            // 型別：HelloWorld.Dtos.AirlCreateDto (你定義的 DTO 類別)
            // 用途：取得整個 DTO 物件，而不只是單一欄位
            // ObjectInstance → 代表目前正在驗證的物件 (這裡是 AirlCreateDto)
            var dto = (HelloWorld.Dtos.AirlCreateDto)validationContext.ObjectInstance;

            // 宣告變數 codeExists
            // 型別：bool (布林值，true/false)
            // 用途：檢查資料庫裡是否有相同的代號
            // _context.AirlMsts → 資料表 AIRL_MST
            // Any(...) → LINQ 方法，檢查是否有至少一筆符合條件的紀錄
            // 條件：a.AirlCode == dto.AirlCode → 資料表裡的代號等於使用者輸入的代號
            var codeExists = _context.AirlMsts.Any(a => a.AirlCode == dto.AirlCode);

            // 宣告變數 nameExists
            // 型別：bool (布林值，true/false)
            // 用途：檢查資料庫裡是否有相同的名稱
            // 條件：a.AirlName == dto.AirlName → 資料表裡的名稱等於使用者輸入的名稱
            var nameExists = _context.AirlMsts.Any(a => a.AirlName == dto.AirlName);

            // if (codeExists) → 判斷布林值是否為 true
            // 如果代號已存在，就回傳一個新的 ValidationResult (失敗)，並附上錯誤訊息
            if (codeExists)
            {
                return new ValidationResult("已存在相同的航空公司代號");
            }

            // if (nameExists) → 判斷布林值是否為 true
            // 如果名稱已存在，就回傳一個新的 ValidationResult (失敗)，並附上錯誤訊息
            if (nameExists)
            {
                return new ValidationResult("已存在相同的航空公司名稱");
            }

            // 如果代號和名稱都沒重複 → 驗證成功
            // ValidationResult.Success → 系統提供的靜態屬性，代表驗證通過
            return ValidationResult.Success;
        }
    }
}
