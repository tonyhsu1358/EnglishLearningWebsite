﻿using HelloWorld.Dtos;
using HelloWorld.Models;

namespace HelloWorld.ViewModels
{
    public class CargoReportViewModel
    {
        // 查詢條件
        public int? AirlId { get; set; }
        public int? MinWeight { get; set; }

        // 下拉選單資料
        public List<AirlMst> Airlines { get; set; } = new List<AirlMst>();

        // 固定查詢結果 (重量 >= 100)
        public List<FligCargoDto> FixedResults { get; set; } = new List<FligCargoDto>();

        // 動態查詢結果 (依使用者輸入)
        public List<FligCargoDto> DynamicResults { get; set; } = new List<FligCargoDto>();
    }
}
