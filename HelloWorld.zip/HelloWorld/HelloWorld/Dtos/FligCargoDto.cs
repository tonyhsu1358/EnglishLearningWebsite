﻿namespace HelloWorld.Dtos
{
    public class FligCargoDto
    {
        public string FligNo { get; set; }
        public string AirlName { get; set; }
        public string DeptAirpName { get; set; }
        public string ArvlAirpName { get; set; }
        public string CargoNo { get; set; }
        public string CargoType { get; set; }
        public decimal CargoWeight { get; set; }
        public string CargoDesc { get; set; }
    }
}
