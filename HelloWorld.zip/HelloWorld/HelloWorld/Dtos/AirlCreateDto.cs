﻿using System.ComponentModel.DataAnnotations;
using HelloWorld.ValidationAttributes;
namespace HelloWorld.Dtos
    {
    //[AirlUnique]自訂驗證標籤除了可以放在欄位上，也可以放在類別上(如此處註解掉的[AirlUnique]所示)
    public class AirlCreateDto
        {
        [AirlUnique]
        [Required(ErrorMessage ="代號不可為空")]
        public string AirlCode { get; set; }
        [AirlUnique]
        [Required(ErrorMessage = "代號不可為空")]
            public string AirlName { get; set; }
        }
    }
