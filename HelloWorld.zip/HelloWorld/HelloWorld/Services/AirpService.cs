﻿using HelloWorld.Models;
using System.Collections.Generic;
using System.Linq;

namespace HelloWorld.Services
{
    // Service 類別：專門負責「機場」相關的資料存取邏輯
    public class AirpService
    {
        // 宣告一個唯讀欄位 _context
        // 型別：HelloWorldContext (DbContext)
        // 用途：連線資料庫，查詢 / 新增 / 修改 / 刪除資料
        private readonly HelloWorldContext _context;

        // 建構子注入 (Dependency Injection)
        // 當系統建立 AirpService 物件時，會自動把 HelloWorldContext 傳進來
        public AirpService(HelloWorldContext context)
        {
            _context = context;
        }

        // 方法：取得所有機場清單 (同步版)
        // 回傳型別：List<AirpMst> → 直接回傳一個機場清單
        public List<AirpMst> GetAirports()
        {
            // 使用 Entity Framework Core 的 ToList()
            // 從資料表 AirpMsts 撈出所有機場資料
            return _context.AirpMsts.ToList();
        }
    }
}
