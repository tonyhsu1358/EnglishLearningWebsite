using Microsoft.EntityFrameworkCore;
using HelloWorld.Models;
using HelloWorld.Services; // 等你產生 Model 後會用到

var builder = WebApplication.CreateBuilder(args);

// 在這裡加入 DbContext ，即注入資料庫物件
// AddDbContext<T>() → 告訴 DI 容器：當有人需要 HelloWorldContext，就用 SQL Server 建立它
// builder.Configuration.GetConnectionString("DefaultConnection") → 從 appsettings.json 讀取連線字串
builder.Services.AddDbContext<HelloWorldContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// 註冊 AirpService 服務
// AddScoped<T>() → 每個 HTTP Request 建立一次 AirpService 物件
// 這樣 Controller 在建構子需要 AirpService 時，DI 容器就會自動提供
builder.Services.AddScoped<AirpService>();

// 加入 MVC Controller + View 支援
// 這行是 ASP.NET Core MVC 的基本設定，讓你能使用 Controller 與 Razor View
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();

app.Run();
